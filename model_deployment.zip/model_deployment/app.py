import pickle
from flask import Flask, request, render_template

app = Flask(__name__)

# Load the model (Pickle example)
#model = pickle.load(open('house_model.pkl', 'rb'))
model = pickle.load(open('model.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    rooms = int(request.form['rooms'])  # Get number of rooms from the form
    area = float(request.form['area'])  # Get area from the form
    
    # Make a prediction using both rooms and area
    prediction = model.predict([[rooms, area]])
    
    return render_template('index.html', predicted_price=f"Predicted House Price:{float(prediction[0]):,.2f} Rwf")

if __name__ == '__main__':
    app.run(debug=True)
