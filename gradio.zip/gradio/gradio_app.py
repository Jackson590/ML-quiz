import gradio as gr
import pickle
import numpy as np

# Load the trained model
with open('house_model.pkl', 'rb') as f:
    model = pickle.load(f)

def predict_price(rooms, area):
    """Predict house price using both number of rooms and area"""
    try:
        # Convert inputs to numerical values
        rooms = int(rooms)
        area = float(area)
        
        # Make prediction
        prediction = model.predict([[rooms, area]])
        
        # Format the output with currency
        return f"Predicted Price: {float(prediction[0]):,.2f} Rwf"
    except Exception as e:
        return f"Error: {str(e)}"

# Create Gradio interface
inputs = [
    gr.Dropdown(list(range(1, 24)), label="Number of Rooms", value=1),
    gr.Number(label="House Area (m²)", value=100)
]

outputs = gr.Label(label="Prediction Result")

title = "House Price Prediction"
description = "Predict house prices based on number of rooms and area"

demo = gr.Interface(
    fn=predict_price,
    inputs=inputs,
    outputs=outputs,
    title=title,
    description=description,
    
)

demo.launch(share=True)  # Generates a public link

if __name__ == "__main__":
    demo.launch()